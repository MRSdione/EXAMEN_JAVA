import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.UUID;

public class Main {

    public static Scanner scanner = new Scanner(System.in);

    public static void main(String args[]) {
        Service service = new Service();
        //Validator v1 = new Validator();
        List<Client> listClients = new ArrayList<>();
        List<Local> listLocals = new ArrayList<>();
        //List<Reservation> listReservations = new ArrayList<>();

        int choix;
        do {
            choix = menu();
            switch (choix) {
                case 1:
                    System.out.println("Bienvenue dans le system d'ajout de local (Chambre / Appartement) !");
                    System.out.println("------------------------------------------------------------------- ");
                    int typeLocalInt;
                    do {
                        System.out.println("Quel type de local voulez vous Ajouter ? ");
                        System.out.println("\t 1- Chambre"); 
                        System.out.println("\t 2- Appartement");

                        int typeLocal = scanner.nextInt();

                        scanner.nextLine();
                        typeLocalInt = (typeLocal);

                    } while (typeLocalInt != 2 && typeLocalInt != 1);
                    Chambre chambre;
                    if (typeLocalInt == 1) {

                        System.out.print("Entrer la localisation : ");
                        String localisation = scanner.nextLine();

                        System.out.print("Entrer le prix (fcfa): ");
                        int prix = scanner.nextInt();

                        System.out.print("Entrer le taux de location : ");
                        double tauxloc = scanner.nextDouble();

                        System.out.print("Entrer la dimension (m²): ");
                        int dimension = scanner.nextInt();
                        System.out.println();
                        System.out.println("Chambre ajouté avec succés" + "\n");

                        chambre = new Chambre(localisation, prix, tauxloc, dimension);
                        service.addLocal(chambre);

                    } else if (typeLocalInt == 2) {

                        System.out.print("Entrer la localisation : ");
                        String localisation = scanner.nextLine();

                        System.out.print("Entrer le prix (fcfa) : ");
                        int prix = scanner.nextInt();

                        System.out.print("Entrer le taux de location : ");
                        double tauxloc = scanner.nextDouble();

                        System.out.print("Entrer le nombre de piece ");
                        int nbrePiece = scanner.nextInt();
                        do {
                            if (nbrePiece < 3) {
                                System.out.println("Attention l'appartement doit avoir au minimum trois piece ");
                                nbrePiece = scanner.nextInt();
                            }

                        } while ((nbrePiece) < 3);
                        System.out.println();
                        System.out.println("Appartement ajouté avec succés" + "\n");

                        Appartement appartement = new Appartement(localisation, prix, tauxloc, nbrePiece);
                        service.addLocal(appartement);

                    }
                    break;
                case 2:
                    System.out.println("Locaux de type Chambre : ");
                    System.out.println("----------------------- ");

                    Service.listerChambre(Service.listLocals);

                    System.out.println("Locaux de type Appartement : ");
                    System.out.println("---------------------------- ");

                    Service.listerAppartement(Service.listLocals);

                    break;
                case 3:
                    System.out.println("Liste des locaux reserves par un client : ");
                    System.out.println("---------------------------- ");
                    Service.listerRerservation();
                    break;
                case 4:
                    System.out.println("Voir les details d'un local : ");
                    System.out.println("---------------------------- ");
                    Service.listerLocal();
                    break;
                case 5:

                    System.out.println("Bienvenue dans le systeme de Reservation (Appartement / Chambre) : ");
                    System.out.println("----------------------------------------------------------------- ");
                    scanner.nextLine();
                    System.out.print("Entrer votre nci (xxxx xxxx xxxxx) : ");
                    String nci = scanner.nextLine();
                    if (Validator.isValidNci(nci) && nci != null) {

                    } else {
                        System.out.println(" NCI incorrect ! Veuillez reessayer.");
                        break;
                    }
                    // SI LE CLIENT N'EXISTE PAS ON CREE UN COMPTE

                    Client client = service.searchClient((nci));
                    if (client == null) {

                        System.out.println("Creation de compte : ");
                        System.out.println("-------------------- ");

                        System.out.print("Entrer votre nom complet : ");
                        String nomComplet = scanner.nextLine();
                        if (Validator.isValidName(nomComplet) && nomComplet != null) {

                        } else {
                            System.out.println(" Nom incorrect ! Veuillez reessayer.");
                            break;
                        }

                        System.out.print("Entrer votre numero (+221 xx xxx xx xx) : ");
                        String tel = scanner.nextLine();
                        if (Validator.isValidPhone(tel)) {

                        } else {
                            System.out.println("Numero incorrect ! Veuillez reessayer.");
                            break;
                        }

                        System.out.print("Entrer votre Adresse de residence : ");
                        String adresse = scanner.nextLine();
                        if (Validator.isValidAdresse(adresse) && adresse != null) {

                        } else {
                            System.out.println("Adresse incorrect ! Veuillez reessayer.");
                            break;
                        }

                        System.out.print("Entrer votre email : ");
                        String email = scanner.nextLine();
                        if (Validator.isValidEmail(email) && email != null) {

                        } else {
                            System.out.println("Email incorrect ! Veuillez reessayer.");
                            break;
                        }

                        client = new Client(nci, nomComplet, tel, adresse, email);
                        service.createClient(client);
                    }

                    String typeReservation;
                    int typeReservationInt;
                    do {
                        System.out.println("Quel type de local voulez vous Reserver ? ");
                        System.out.println("\t 1- Chambre");
                        System.out.println("\t 2- Appartement");
                        typeReservation = scanner.nextLine();
                        typeReservationInt = Integer.parseInt(typeReservation);

                    } while (typeReservationInt != 2 && typeReservationInt != 1);
                    // Local local;
                    //Reservation reservation = new Reservation();
                    if (typeReservationInt == 1) {
                        Service.listerChambre(Service.listLocals);
                        System.out.print("Entrer la reference de la chambre que vous voulez reserver : ");
                        String input = scanner.nextLine();

                        LocalDate date = LocalDate.now();
                        String etat = "reservé";
                        System.out.print("Combien de jours voulez vous reserver cette chambre : ");
                        String duree = scanner.nextLine();

                        Reservation reservation = new Reservation(date, duree, etat, input);
                        Service.addReservation(reservation);
                        reservation.setClient(reservation);
                        System.out.println("La reservation de la chambre a reussi. Son id est : " + reservation.getId());
                    }else{
                        Service.listerAppartement(Service.listLocals);
                        System.out.print("Entrer la reference de l'appartement que vous voulez reserver :");
                        String input = scanner.nextLine();
                        LocalDate date = LocalDate.now();
                        String etat = "reservé";
                        System.out.print("Combien de jours que vous voulez reserver cet appartement : ");
                        String duree = scanner.nextLine();

                        Reservation reservation = new Reservation(date, duree, etat, input);
                        Service.addReservation(reservation);
                        reservation.setClient(reservation);
                        System.out.println("La reservation de l'appartement a reussi. Son id est : " + reservation.getId());
                        
                    }
                    break;

                case 6:
                    scanner.nextLine();
                    System.out.println("Annulation de reservation (Appartement / Chambre): ");
                    System.out.println("-------------------------------------------------- ");
                    System.out.print("Entrer votre nci (xxxx xxxx xxxxx) : ");
                    nci = scanner.nextLine();
                    client = service.searchClient(nci);
                    if (Validator.isValidNci(nci) && nci != null && client != null) {
                        System.out.println("Entrer l'id de la reservation que vous voulez annuler : ");
                        String delete = scanner.nextLine();
                        Reservation reservation = new Reservation();
                        if(Service.listReservations.equals(delete)){
                            Service.listReservations.remove(reservation);
                        }else{
                            System.out.println("IL n'existe pas de reservation avec cet ID");
                        }
                    }else{
                        System.out.println(" NCI incorrect ou client n'existe pas.");
                        break;
                    }
                case 7:
                    System.out.println("Liste des locaux disponibles: ");
                    System.out.println("----------------------------- ");
                case 8:
                    System.out.println("FIN DU PROGRAMME ");
                    break;
                default:
                    System.out.println("Choix incorrect ! Veuillez recommencer. ");
            }

        } while (choix != 8);
    }

    public static int menu() {
        int choix;
        System.out.println("************Menu*************");
        System.out.println("1. Ajouter local");
        System.out.println("2. Lister les locaux par type");
        System.out.println("3. Lister locaux reserves par un client");
        System.out.println("4. Voir les details d'un local");
        System.out.println("5. Faire une reservation");
        System.out.println("6. Annuler une reservation");
        System.out.println("7. Lister les locaux disponibles");
        System.out.println("8. Exit");
        System.out.println("-------------------------------------------------");
        System.out.print("Faites votre choix (1 - 8) : ");
        choix = scanner.nextInt();
        return choix;
    }
}