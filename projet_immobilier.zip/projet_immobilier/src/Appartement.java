
public class Appartement extends Local {

    private int nbrepiece;


    public Appartement() {


    public Appartement(int nbrepiece) {
        this.nbrepiece = nbrepiece;
    }

    public Appartement(int typeLocal, String localisation, int prix, double tauxloc, int nbrpiece) {
        super(typeLocal, localisation, prix, tauxloc);
        this.nbrepiece = nbrepiece;
    }

    
    public int getNbrepiece() {
        return nbrepiece;
    }

    public void setNbrepiece(int nbrepiece) {
        this.nbrepiece = nbrepiece;
    }

    // METHODE AFFICHER
    @Override
    public String toString() {
        String result = " Reference = " + reference + ", Type local = " + typeLocal + ", Localisation = " + localisation
                + ", Prix = " + prix + ", Taux local = " + tauxloc + ", Nombre de piece = " + nbrepiece;
        return result;
    }

    
    private Local localAppartement;

    public Local getLocal() {
        return this.localAppartement;
    }

    public void setLocal(Local locale) {
        this.localAppartement = locale;
    }

}
