
public class Appartement extends Local {

    private int nbrePiece;

 
    public Appartement() {
        type = "Appartement";
    }

    public Appartement(String localisation, int prix, double tauxLoc, int nbrePiece) {
        super(localisation, prix, tauxLoc);
        type = "Appartement";
        this.setNbrePiece(nbrePiece);
    }

    
    public int getNbrePiece() {
        return nbrePiece;
    }

    public void setNbrePiece(int nbrePiece) {
        this.nbrePiece = nbrePiece;
    }

    
    @Override
    public double cout(int prix, double tauxLoc){
        return prix + tauxLoc * prix;
    }

    
    @Override
    public String afficher() {
        return super.afficher()
        + "\n Nombre de Piece : " + nbrePiece 
        + "\n Cout de Location : " + cout(prix, tauxLoc) + "\n";
    }

    
    private Local localAppartement;

    public Local getLocal() {
        return this.localAppartement;
    }

    public void setLocal(Local locale) {
        this.localAppartement = locale;
    }

}
