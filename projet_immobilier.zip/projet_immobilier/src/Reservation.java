import java.time.LocalDate;
//import java.util.Date;

public class Reservation implements IAffiche {

    private static final int FORMAT = 1;
    private LocalDate date;
    private String duree;
    private String etat;
    private String id;
    public String input;
    private int nombreCompte;


   // Creation des constructeurs
    public Reservation() {

    }

    
    public Reservation(LocalDate date, String duree, String etat, String input) {
        setDate(date);
        setDuree(duree);
        setEtat(etat);
        this.input = input;
    }


    public Reservation(String etat) {
        setEtat(etat);
        this.id = generateId();
    }

    public Reservation(String duree, String etat, String id) {
        setDuree(duree);
        setEtat(etat);
        setId(id);
    }

    // Creation des methodes
    private String generateId() {
        String nombreZero = "";
        String nombreCompteString = String.valueOf(++nombreCompte);
        while (nombreZero.length() + nombreCompteString.length() != FORMAT) {
            nombreZero += "0";
        }
        return nombreZero + nombreCompteString;
    }
   

    // Creation des getters et setters
    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getDuree() {
        return duree;
    }

    public void setDuree(String duree) {
        this.duree = duree;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    // Redefinition methode afficher()
    @Override
    public String afficher() {
        return "\n ID : " + getId()
            + "\n Date : " + getDate()
            + "\n Durée : " + getDuree()
            + "\n Etat : " + getEtat();
    }

    public void setClient(Reservation reservation) {
    }


}
