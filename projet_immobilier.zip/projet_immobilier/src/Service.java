import java.util.List;
import java.util.ArrayList;

public class Service {

    static List<Client> listClients = new ArrayList<>();
    static List<Local> listLocals = new ArrayList<>();
    static List<Reservation> listReservations = new ArrayList<>();

    public Client searchClient(String nci) {
        Client client = new Client();
        client.setNci(nci);
        int pos = listClients.indexOf(client);
        if (pos != -1) {
            return listClients.get(pos);
        }
        return null;
    }

    public void createClient(Client client) {
        listClients.add(client);
    }


    public void addLocal(Local local) {
        listLocals.add(local);
    }

    public static void listerLocal() {
        for (Local local : listLocals) {
            System.out.println(local.afficher());
        }
    }

    public static void listerChambre(List<Local> listLocals) {
        for (Local local : listLocals) {
            if (local.getType() == "Chambre") {
                System.out.println(local.afficher());
            }
        }
    }

    public static void listerAppartement(List<Local> listLocals) {
        for (Local local : listLocals) {
            if (local.getType() == "Appartement") {
                System.out.println(local.afficher());
            }
        }
    }


    public static void addReservation(Reservation reservation) {
        listReservations.add(reservation);
    }

    public static void deleteReservation(Reservation reservation) {
        listReservations.remove(reservation);
    }

    public static void listerRerservation() {
        for (Reservation reservation : listReservations) {
            System.out.println(reservation.afficher());
        }
    }

}