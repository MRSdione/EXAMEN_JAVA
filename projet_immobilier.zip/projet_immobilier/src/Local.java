public abstract class Local implements IAffiche{
    
    protected String ref;
    protected String type;
    protected String localisation;
    protected int prix;
    protected double tauxLoc;
    private int FORMAT = 4;
    public static int nombreCompte;

    // Creation des constructeurs
    public Local() {
        ref = getRef();
    }

    public Local(String localisation, int prix, double tauxLoc) {
        this.ref = generateRef();
        this.localisation = localisation;
        this.prix = prix;
        this.tauxLoc = tauxLoc;
    }

    // Creation des getters et setters
    public String getRef() {
        return ref;
    }

    public String getLocalisation() {
        return localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }

    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public double getTauxLoc() {
        return tauxLoc;
    }

    public void setTauxLoc(double tauxLoc) {
        this.tauxLoc = tauxLoc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    // Creation des methode 
    private String generateRef() {
        String firstPart = "REF";
        String nombreZero = "";
        String nombreCompteString = String.valueOf(++nombreCompte);
        while (nombreZero.length() + nombreCompteString.length() != FORMAT) {
            nombreZero += "0";
        }
        return firstPart + nombreZero + nombreCompteString;
    }

    public abstract double cout(int prix, double tauxLoc);

    // Redefinition methode afficher
    @Override
    public String afficher() {
        return " Type de Local : " + getType()
            + "\n Reference : " + getRef()
            + "\n Prix : " + getPrix()
            + "\n Localisation : " + getLocalisation()
            + "\n Taux Location : " + getTauxLoc();
    }


}