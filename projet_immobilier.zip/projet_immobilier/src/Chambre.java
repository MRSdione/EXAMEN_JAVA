import java.util.Scanner;
public class Chambre extends Local {
    Scanner sc = new Scanner(System.in);
    private int dimension;

    // Creation des constructeurs
    public Chambre() {
        type = "Chambre";
    }

    public Chambre(String localisation, int prix, double tauxloc, int dimension) {
        super(localisation, prix, tauxloc);
        type = "Chambre";
        this.setDimension(dimension);
    }

    // Creation des getters et setters
    public int getDimension() {
        return dimension;
    }

    public void setDimension(int dimension) {
        this.dimension = dimension;
    }

    // Creation des methodes
    @Override
    public double cout(int prix, double tauxLoc){
        return prix + tauxLoc * prix;
    }

    // Redefinition methode afficher()
    @Override
    public String afficher() {
        return super.afficher()
        + "\n Dimension : " + getDimension() 
        + "\n Cout de Location : " + cout(prix, tauxLoc)+ "\n";
    }

    // Propriete navigationnelle
    private Local localChambre;

    public Local getLocal() {
        return this.localChambre;
    }

    public void setLocal(Local local) {
        this.localChambre = local;
    }

}
